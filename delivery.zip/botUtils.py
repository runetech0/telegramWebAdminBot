

class BotUtils:
    def __init__(self, client, dbUtils, sheets):
        self.client = client
        self.dbUtils = dbUtils
        self.sheets = sheets
